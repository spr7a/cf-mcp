# cf-mcp-orange 🚀

[![PyPI version](https://img.shields.io/pypi/v/cf-mcp-orange)](https://pypi.org/project/cf-mcp-orange/)

A **complete, all-in-one MCP (Model Context Protocol) server** for Codeforces. 
Designed to supercharge AI coding assistants like **Cline** and **Claude Desktop**.

---

## ✨ Features (9 Powerful Tools)

1. **`get_user`** – Fetch a detailed profile (rating, max rating, last 5 contests, problem stats by difficulty, top 10 categories).
2. **`compare_user`** – Side-by-side comparison of two Codeforces users.
3. **`get_problemlist`** – Search the entire problemset by rating range, topic tags (`AND`/`OR`), and sorting.
4. **`get_problem`** – Retrieve the full problem statement, rating, and tags for any specific contest/problem ID.
5. **`get_practiceproblems`** – Identify a user's weakest core topics and recommend 3 targeted problems within `+300` rating.
6. **`get_random_practice`** – A completely random problem within `+/- 300` of a user's current rating.
7. **`get_upsolve`** – Analyzes a user's last 10 contests and recommends unsolved problems within their rating range.
8. **`get_status`** – Summarizes the last 1000 submissions (AC/WA/TLE counts) and the 20 most recent attempts.

---

## 📦 Changelog

### v1.0.6 (2026-07-04)
- 🐛 **Fixed**: `ModuleNotFoundError` when running the server — changed absolute import to relative import in `get_problem.py`
- ✅ **Verified**: All 8 tools tested and working (get_user, compare_user, get_problemlist, get_problem, get_practiceproblems, get_random_practice, get_upsolve, get_status)

---

## 🛠️ Installation & Configuration (No Keys Required!)

You don't need to clone or manually install anything! Just add this to your `cline_mcp_settings.json` or `mcp.json`:

```json
{
  "mcpServers": {
    "cf-mcp-orange": {
      "command": "uvx",
      "args": ["cf-mcp-orange"]
    }
  }
}